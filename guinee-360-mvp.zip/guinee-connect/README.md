# Guinée 360 — MVP

Application web responsive en français, utilisable sur téléphone et ordinateur.

## Démarrer
Ouvrez `index.html` dans un navigateur moderne. Aucune installation nécessaire.

## Fonctions
- Recherche par nom, description, catégorie et ville
- Fiches professionnelles et liens téléphone, e-mail, site web, WhatsApp
- Formulaire d'inscription avec champs Commune, Quartier facultatif et code postal facultatif
- Tableau de bord administrateur : approbation, masquage et suppression
- Données enregistrées dans le `localStorage` du navigateur

Code administrateur **de démonstration** : `1234`.

## Limitations importantes
Il s'agit d'un prototype local : chaque navigateur possède ses propres données. Le code admin est visible dans le source et ne fournit **aucune sécurité réelle**. Les fiches initiales sont fictives. Ne pas utiliser ce prototype tel quel pour recueillir des données réelles en production.

## Étapes de mise en production
Ajouter une base de données partagée, authentification administrateur côté serveur, gestion des comptes professionnels, validation et anti-spam, politique de confidentialité, sauvegardes et hébergement HTTPS. Pour les magasins iOS/Android, créer des clients mobiles ou une enveloppe native et suivre les exigences des stores.

## Identité visuelle
Logo : `logo.svg` ; couleurs rouge #CE1126, jaune #FCD116, vert #007A5E, bleu nuit #10232D. Slogan : Toute la Guinée à portée de main.

Les données locales restent sous la clé historique `guinee-connect-mvp-v1` pour préserver les inscriptions existantes sur le même navigateur et la même origine.

Mise à jour : champ facultatif « Code postal » dans le formulaire d’inscription, enregistré et affiché dans les fiches et l’administration.

## Photos des entreprises
Le formulaire accepte une photo de profil facultative (JPG/PNG/WebP, 5 Mo maximum). Elle est redimensionnée dans le navigateur, prévisualisée, puis stockée localement avec la fiche. Les photos apparaissent dans les résultats, les profils et le tableau de bord. Le stockage local est limité et ne remplace pas un hébergement sécurisé pour la production.

## Notes et avis
Les visiteurs peuvent attribuer 1 à 5 étoiles et laisser un commentaire sur les fiches publiées. La moyenne et le nombre d’avis apparaissent dans les résultats et les profils. Les administrateurs peuvent supprimer des avis. Démonstration uniquement : avis stockés localement, limite d’un avis par navigateur facilement contournable ; une authentification et modération côté serveur seront nécessaires en production.

## Google Maps
Les fiches publiques incluent une carte Google Maps intégrée et un lien vers Google Maps. Le formulaire propose une adresse / un repère précis facultatif pour améliorer la géolocalisation. Sans adresse précise, la carte affiche une recherche approximative de la commune et de la ville. Connexion internet nécessaire. Aucune clé API nécessaire pour cette version utilisant maps.google.com.

## Couverture géographique
Le menu Ville / Préfecture contient les 33 préfectures de Guinée, Conakry et une option « Autre ville ». Les valeurs existantes restent compatibles.

## Catégories et sous-catégories
Le formulaire propose des sous-catégories dépendantes de la catégorie principale. La recherche filtre sur les deux niveaux et la ville. Le tableau de bord permet d’ajouter des catégories, d’ajouter, renommer et supprimer des sous-catégories non utilisées. La taxonomie est conservée dans le stockage local du navigateur. Les fiches existantes sans sous-catégorie restent visibles lors des recherches sans filtre de sous-catégorie.

Mise à jour : Santé comprend uniquement Hôpitaux, Cliniques, Pharmacies et Laboratoires. La catégorie de restauration s’intitule Restaurants.


Mise à jour catégories : Restaurants (Restaurants, Fast-food, Dibiteries, Cafés, Boulangeries) ; Auto-écoles déplacées vers Éducation ; Concessionnaires automobiles ajoutés à Automobile ; Transport disponible comme catégorie distincte. Les taxonomies locales existantes sont adaptées au chargement.

Mise à jour Commerce : ajout des sous-catégories Galeries commerciales et Centres commerciaux, y compris pour les taxonomies déjà enregistrées localement.

Mise à jour : nouvelle catégorie Ouvriers (maçons, peintres en bâtiment, carreleurs, soudeurs, manœuvres, ferrailleurs, coffreurs, électriciens du bâtiment, plombiers, menuisiers). Tourisme : agences de voyage, guides touristiques, sites touristiques. Synchronisation des catégories déjà enregistrées localement.

- Catégorie Artisans retirée. Les fiches existantes Artisans sont reclassées dans Ouvriers (Électriciens devient Électriciens du bâtiment).
